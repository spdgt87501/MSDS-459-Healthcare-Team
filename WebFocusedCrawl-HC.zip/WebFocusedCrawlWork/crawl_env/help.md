### Use this to activate the venv<br>
source crawl_env/Scripts/activate

### Wikipedia Scraper<br>
By defult the scraper for Wikipedia is off. To activate navigate to articles-spider.py and SCRAPE_WIKIPEDIA set to True

-- or -- 

Override the False line with this command at run time:<br>
scrapy crawl articles-spider -s SCRAPE_WIKIPEDIA=True